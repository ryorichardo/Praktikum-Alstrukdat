/**
 * NIM       : 13516030
 * Nama      : Yonas Adiel Wiguna
 * Tanggal   : 24 Agustus 2017
 * Topik     : Pengenalan C
 * Deskripsi : Menampilkan Hello World di layar
 */

#include "stdio.h"

int main() {
	printf("Hello, World!\n");

	return 0;
}
